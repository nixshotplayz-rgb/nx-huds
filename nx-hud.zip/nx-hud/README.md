# NX HUD modules (stage 1) — UNBUILT, UNTESTED
Elements: FPS, CPS (rolling 1s, L|R), Keystrokes (uses real keybinds), Armor + durability %.
Each has enabled / x / y / scale (0.5-3) / opacity (0-100%), saved to config/nx-hud.json.
Set opacity 4 for the "Minimal HUD" look.

Needs a Gradle/Fabric Loom project (not included yet). Verify against 1.21.11:
- HudElementRegistry / VanillaHudElements (Fabric API) names
- Matrix3x2fStack calls (pushMatrix/translate/scale/popMatrix) on DrawContext
- Mouse.onMouseButton signature in MouseMixin
- Mapping names (code uses Yarn-style names)
Not yet done: ping, coords, potions, editor screen, per-mode profiles.
