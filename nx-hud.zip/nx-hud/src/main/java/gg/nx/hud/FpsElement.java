package gg.nx.hud;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

public class FpsElement extends HudElement {
    public FpsElement() { super("fps", 4, 4); }
    private String text(MinecraftClient mc) { return mc.getCurrentFps() + " FPS"; }
    @Override public int width()  { return 52; }
    @Override public int height() { return 12; }
    @Override protected void draw(DrawContext ctx, MinecraftClient mc) {
        ctx.fill(0, 0, width(), height(), argb(0x000000, 0.4f));
        ctx.drawText(mc.textRenderer, text(mc), 3, 2, argb(0xFFFFFF, 1f), false);
    }
}
