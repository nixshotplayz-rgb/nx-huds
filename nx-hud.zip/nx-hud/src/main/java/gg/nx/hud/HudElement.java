package gg.nx.hud;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/** Base class: position, scale, opacity (0-100%), enabled flag. All persisted via HudConfig. */
public abstract class HudElement {
    public final String id;
    public boolean enabled = true;
    public int x, y;
    public float scale = 1.0f;
    public int opacity = 100; // percent, 0..100

    protected HudElement(String id, int x, int y) { this.id = id; this.x = x; this.y = y; }

    public abstract int width();
    public abstract int height();
    protected abstract void draw(DrawContext ctx, MinecraftClient mc);

    /** Applies position/scale transform, then draws. Skips when disabled or fully transparent. */
    public final void render(DrawContext ctx, MinecraftClient mc) {
        if (!enabled || opacity <= 0) return;
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().translate(x, y);
        ctx.getMatrices().scale(scale, scale);
        draw(ctx, mc);
        ctx.getMatrices().popMatrix();
    }

    /** ARGB with this element's opacity applied to the given RGB (alpha of input ignored). */
    protected int argb(int rgb, float baseAlpha) {
        int a = Math.round(255f * baseAlpha * (opacity / 100f));
        return (Math.max(0, Math.min(255, a)) << 24) | (rgb & 0xFFFFFF);
    }

    public void clamp() {
        scale = Math.max(0.5f, Math.min(3.0f, scale));
        opacity = Math.max(0, Math.min(100, opacity));
    }
}
