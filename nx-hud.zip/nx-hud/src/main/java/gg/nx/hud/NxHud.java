package gg.nx.hud;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.Identifier;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import java.util.*;

public class NxHud implements ClientModInitializer {
    public static final Map<String, HudElement> ELEMENTS = new LinkedHashMap<>();

    @Override public void onInitializeClient() {
        for (HudElement e : List.of(new FpsElement(), new CpsElement(), new KeystrokesElement(), new ArmorElement()))
            ELEMENTS.put(e.id, e);
        HudConfig.load(ELEMENTS.values());

        HudElementRegistry.attachElementAfter(VanillaHudElements.MISC_OVERLAYS, Identifier.of("nx", "hud"),
            (ctx, tick) -> {
                MinecraftClient mc = MinecraftClient.getInstance();
                if (mc.options.hudHidden || mc.player == null) return;
                for (HudElement e : ELEMENTS.values()) e.render(ctx, mc);
            });
        // Cycle performance preset (default key: O)
        KeyBinding cycle = KeyBindingHelper.registerKeyBinding(
            new KeyBinding("key.nx.preset", GLFW.GLFW_KEY_O, KeyBinding.Category.MISC));
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (cycle.wasPressed()) {
                PerfPreset n = PerfPreset.current.next();
                n.apply(mc);
                if (mc.player != null) mc.player.sendMessage(Text.literal("NX preset: " + n.label), true);
            }
        });
        for (String m : new String[]{"sodium", "lithium", "ferritecore", "immediatelyfast", "entityculling"})
            org.slf4j.LoggerFactory.getLogger("NX/Perf").info("{}: {}", m,
                FabricLoader.getInstance().isModLoaded(m) ? "installed" : "not installed");
        Runtime.getRuntime().addShutdownHook(new Thread(() -> HudConfig.save(ELEMENTS.values())));
    }
}
