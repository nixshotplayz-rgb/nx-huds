package gg.nx.hud.mixin;

import gg.nx.hud.CpsTracker;
import net.minecraft.client.Mouse;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Mouse.class)
public class MouseMixin {
    // NOTE: verify this signature against 1.21.11 mappings; it has changed across versions (MouseInput in newer builds).
    @Inject(method = "onMouseButton", at = @At("HEAD"))
    private void nx$click(long window, int button, int action, int mods, CallbackInfo ci) {
        if (action == 1) CpsTracker.click(button);
    }
}
