package gg.nx.hud;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;

/** WASD + jump + LMB/RMB. Reads the player's actual key bindings, so rebinds and touch controls are honored. */
public class KeystrokesElement extends HudElement {
    private static final int K = 20, G = 2;
    public KeystrokesElement() { super("keystrokes", 4, 60); }
    @Override public int width()  { return K * 3 + G * 2; }
    @Override public int height() { return K * 3 + G * 3 + 4; }

    @Override protected void draw(DrawContext ctx, MinecraftClient mc) {
        var o = mc.options;
        key(ctx, mc, o.forwardKey, "W", K + G, 0, K);
        key(ctx, mc, o.leftKey,    "A", 0, K + G, K);
        key(ctx, mc, o.backKey,    "S", K + G, K + G, K);
        key(ctx, mc, o.rightKey,   "D", 2 * (K + G), K + G, K);
        key(ctx, mc, o.attackKey,  "L", 0, 2 * (K + G), (K * 3 + G * 2 - G) / 2);
        key(ctx, mc, o.useKey,     "R", (K * 3 + G * 2 + G) / 2, 2 * (K + G), (K * 3 + G * 2 - G) / 2);
        key(ctx, mc, o.jumpKey, "—", 0, 3 * (K + G), K * 3 + G * 2, 8);
    }
    private void key(DrawContext c, MinecraftClient mc, KeyBinding kb, String label, int x, int y, int w) { key(c, mc, kb, label, x, y, w, K); }
    private void key(DrawContext c, MinecraftClient mc, KeyBinding kb, String label, int x, int y, int w, int h) {
        boolean down = kb.isPressed();
        c.fill(x, y, x + w, y + h, argb(down ? 0xFFFFFF : 0x000000, down ? 0.55f : 0.4f));
        int tw = mc.textRenderer.getWidth(label);
        c.drawText(mc.textRenderer, label, x + (w - tw) / 2, y + (h - 8) / 2 + 1,
                argb(down ? 0x000000 : 0xFFFFFF, 1f), false);
    }
}
