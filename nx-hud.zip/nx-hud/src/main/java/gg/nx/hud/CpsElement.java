package gg.nx.hud;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

public class CpsElement extends HudElement {
    public CpsElement() { super("cps", 4, 20); }
    @Override public int width()  { return 60; }
    @Override public int height() { return 12; }
    @Override protected void draw(DrawContext ctx, MinecraftClient mc) {
        ctx.fill(0, 0, width(), height(), argb(0x000000, 0.4f));
        ctx.drawText(mc.textRenderer, CpsTracker.left() + " | " + CpsTracker.right() + " CPS",
                3, 2, argb(0xFFFFFF, 1f), false);
    }
}
