package gg.nx.hud;

import com.google.gson.*;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.nio.file.*;
import java.util.*;

/** Saves/loads element settings to config/nx-hud.json. Bad or missing data falls back to defaults. */
public final class HudConfig {
    private static final Logger LOG = LoggerFactory.getLogger("NX/HudConfig");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("nx-hud.json");

    public static void load(Collection<HudElement> els) {
        if (!Files.exists(FILE)) return;
        try {
            JsonObject root = JsonParser.parseString(Files.readString(FILE)).getAsJsonObject();
            for (HudElement e : els) {
                if (!root.has(e.id)) continue;
                JsonObject o = root.getAsJsonObject(e.id);
                if (o.has("enabled")) e.enabled = o.get("enabled").getAsBoolean();
                if (o.has("x")) e.x = o.get("x").getAsInt();
                if (o.has("y")) e.y = o.get("y").getAsInt();
                if (o.has("scale")) e.scale = o.get("scale").getAsFloat();
                if (o.has("opacity")) e.opacity = o.get("opacity").getAsInt();
                e.clamp();
            }
        } catch (Exception ex) {
            LOG.error("Could not read {}; using defaults", FILE, ex);
            try { Files.move(FILE, FILE.resolveSibling("nx-hud.json.bad"), StandardCopyOption.REPLACE_EXISTING); }
            catch (Exception ignored) {}
        }
    }

    public static void save(Collection<HudElement> els) {
        JsonObject root = new JsonObject();
        for (HudElement e : els) {
            JsonObject o = new JsonObject();
            o.addProperty("enabled", e.enabled); o.addProperty("x", e.x); o.addProperty("y", e.y);
            o.addProperty("scale", e.scale);     o.addProperty("opacity", e.opacity);
            root.add(e.id, o);
        }
        try {
            Files.createDirectories(FILE.getParent());
            Path tmp = FILE.resolveSibling("nx-hud.json.tmp");
            Files.writeString(tmp, GSON.toJson(root));
            Files.move(tmp, FILE, StandardCopyOption.REPLACE_EXISTING);
        } catch (Exception ex) { LOG.error("Could not save {}", FILE, ex); }
    }
    private HudConfig() {}
}
