package gg.nx.hud;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;

/** Helmet/chest/legs/boots + mainhand with durability %. Durability color: green > 50%, yellow > 25%, else red. */
public class ArmorElement extends HudElement {
    private static final EquipmentSlot[] SLOTS = {
        EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET, EquipmentSlot.MAINHAND };
    public ArmorElement() { super("armor", 4, 130); }
    @Override public int width()  { return 44; }
    @Override public int height() { return SLOTS.length * 18; }

    @Override protected void draw(DrawContext ctx, MinecraftClient mc) {
        if (mc.player == null) return;
        int row = 0;
        for (EquipmentSlot s : SLOTS) {
            ItemStack st = mc.player.getEquippedStack(s);
            if (st.isEmpty()) continue;
            int y = row++ * 18;
            ctx.drawItem(st, 0, y);
            if (st.isDamageable()) {
                int max = st.getMaxDamage();
                int pct = Math.round(100f * (max - st.getDamage()) / max);
                int rgb = pct > 50 ? 0x55FF55 : pct > 25 ? 0xFFFF55 : 0xFF5555;
                ctx.drawText(mc.textRenderer, pct + "%", 20, y + 4, argb(rgb, 1f), false);
            }
        }
    }
}
