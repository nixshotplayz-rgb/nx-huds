package gg.nx.hud;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** Client-side video presets. Only changes vanilla options; Sodium/Lithium do the heavy lifting if installed. */
public enum PerfPreset {
    ULTRA_FPS("Ultra FPS",      6,  5, ParticlesMode.MINIMAL,   false, GraphicsMode.FAST,  false, 0.5, CloudRenderMode.OFF,  0, 0),
    BALANCED("Balanced",        10, 8, ParticlesMode.DECREASED, true,  GraphicsMode.FAST,  false, 0.75, CloudRenderMode.FAST, 2, 2),
    BEAUTIFUL("Beautiful",      16, 12, ParticlesMode.ALL,      true,  GraphicsMode.FANCY, false, 1.0, CloudRenderMode.FANCY, 4, 4),
    LOW_END_ANDROID("Low-End Android", 4, 4, ParticlesMode.MINIMAL, false, GraphicsMode.FAST, true, 0.5, CloudRenderMode.OFF, 0, 0);

    private static final Logger LOG = LoggerFactory.getLogger("NX/Perf");
    public final String label;
    final int view, sim; final ParticlesMode particles; final boolean shadows;
    final GraphicsMode gfx; final boolean vsync; final double entityDist;
    final CloudRenderMode clouds; final int biomeBlend, mipmaps;

    PerfPreset(String l, int v, int s, ParticlesMode p, boolean sh, GraphicsMode g, boolean vs,
               double ed, CloudRenderMode c, int bb, int mm) {
        label = l; view = v; sim = s; particles = p; shadows = sh; gfx = g; vsync = vs;
        entityDist = ed; clouds = c; biomeBlend = bb; mipmaps = mm;
    }

    public static PerfPreset current = BALANCED;

    public void apply(MinecraftClient mc) {
        try {
            GameOptions o = mc.options;
            o.getViewDistance().setValue(view);
            o.getSimulationDistance().setValue(sim);
            o.getParticles().setValue(particles);
            o.getEntityShadows().setValue(shadows);
            o.getGraphicsMode().setValue(gfx);
            o.getEnableVsync().setValue(vsync);
            o.getEntityDistanceScaling().setValue(entityDist);
            o.getCloudRenderMode().setValue(clouds);
            o.getBiomeBlendRadius().setValue(biomeBlend);
            o.getMipmapLevels().setValue(mipmaps);
            if (this == LOW_END_ANDROID) o.getMaxFps().setValue(60);
            o.write();
            current = this;
            LOG.info("Applied preset {}", label);
        } catch (Throwable t) { LOG.error("Failed to apply preset {}", label, t); }
    }

    public PerfPreset next() { PerfPreset[] v = values(); return v[(ordinal() + 1) % v.length]; }
}
